<?php ob_start();
session_start();

include("dbms.php");
include("functions.php");
?>